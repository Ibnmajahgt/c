require 'csv'
require 'bcrypt'

class User
  # Method to authenticate user with CSV as fallback
  def self.authenticate(email, password)
    # If using a database (from my_user_model.rb):
    user_model = User.new
    user = user_model.find_by_email(email)
    return false unless user && BCrypt::Password.new(user['password']) == password

    # Fallback to CSV (if no match in the database):
    CSV.foreach('users.csv', headers: true) do |row|
      return true if row['email'] == email && row['password'] == password
    end
    false
  end

  # (Optional) Add user creation for CSV for demonstration purposes
  def self.create_user_in_csv(email, password)
    CSV.open('users.csv', 'a', headers: %w[email password]) do |csv|
      csv << [email, BCrypt::Password.create(password)]
    end
  end
end
