require 'sqlite3'

class User
  def initialize
    @db = SQLite3::Database.new 'db.sql'
    @db.results_as_hash = true
    @db.execute <<-SQL
      CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        firstname TEXT NOT NULL,
        lastname TEXT NOT NULL,
        age INTEGER NOT NULL,
        password TEXT NOT NULL,
        email TEXT UNIQUE NOT NULL
      );
    SQL
  end

  # Create a new user
  def create(user_info)
    @db.execute(
      'INSERT INTO users (firstname, lastname, age, password, email) VALUES (?, ?, ?, ?, ?)',
      [user_info[:firstname], user_info[:lastname], user_info[:age], user_info[:password], user_info[:email]]
    )
    @db.last_insert_row_id
  rescue SQLite3::ConstraintException
    raise 'Email already exists'
  end

  # Find user by ID
  def find(user_id)
    @db.execute('SELECT * FROM users WHERE id = ?', [user_id]).first
  end

  # Find user by email
  def find_by_email(email)
    @db.execute('SELECT * FROM users WHERE email = ?', [email]).first
  end

  # Get all users
  def all
    @db.execute('SELECT * FROM users')
  end

  # Update a user's attribute
  def update(user_id, attribute, value)
    @db.execute("UPDATE users SET #{attribute} = ? WHERE id = ?", [value, user_id])
    find(user_id)
  end

  # Delete a user by ID
  def destroy(user_id)
    @db.execute('DELETE FROM users WHERE id = ?', [user_id])
  end

  # Verify email and password for sign-in
  def sign_in(email, password)
    user = find_by_email(email)
    return nil unless user && BCrypt::Password.new(user['password']) == password

    user
  end
end
