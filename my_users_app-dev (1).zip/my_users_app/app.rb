# app.rb
require 'sinatra'
require 'json'
require 'bcrypt'
require 'securerandom'
require_relative 'my_user_model'

enable :sessions
set :session_secret, SecureRandom.hex(64) # Secure session secret

set :port, 8080
set :bind, '0.0.0.0'
set :views, './views'

# Use a before filter to initialize @user_model
before do
  @user_model ||= User.new
end

helpers do
  def current_user
    @current_user ||= @user_model.find(session[:user_id]) if session[:user_id]
  end
end

# GET user by ID
get '/users/:id' do
  user_id = params[:id]
  user = @user_model.find(user_id)

  if user
    content_type :json
    user.reject { |k| k == 'password' }.to_json
  else
    status 404
    { error: "User with ID #{user_id} not found" }.to_json
  end
end

# GET all users
get '/users' do
  users = @user_model.all.map { |user| user.reject { |k| k == 'password' } }
  users.to_json
end

# POST create a new user
post '/users' do
  user_info = {
    firstname: params[:firstname],
    lastname: params[:lastname],
    age: params[:age],
    password: BCrypt::Password.create(params[:password]),
    email: params[:email]
  }

  begin
    user_id = @user_model.create(user_info)
    user = @user_model.find(user_id).reject { |k| k == 'password' }
    status 201
    user.to_json
  rescue SQLite3::ConstraintException
    halt 400, { error: 'Email must be unique' }.to_json
  end
end

# POST sign in
post '/sign_in' do
  email = params[:email]
  password = params[:password]

  user = @user_model.find_by_email(email)

  if user && BCrypt::Password.new(user['password']) == password
    session[:user_id] = user['id']
    { message: 'Sign-in successful', user: user.reject { |k| k == 'password' } }.to_json
  else
    halt 401, { error: 'Invalid email or password' }.to_json
  end
end

# PUT update user details
put '/users' do
  halt 401, { error: 'Not signed in' }.to_json unless current_user

  updates = {}
  updates[:password] = BCrypt::Password.create(params[:password]) if params[:password]

  updates.each do |attribute, value|
    @user_model.update(current_user['id'], attribute.to_s, value)
  end

  updated_user = @user_model.find(current_user['id']).reject { |k| k == 'password' }
  updated_user.to_json
end

# DELETE sign out
delete '/sign_out' do
  session.clear
  { message: 'Sign-out successful' }.to_json
end

# DELETE delete current user
delete '/users' do
  halt 401, { error: 'Not signed in' }.to_json unless current_user
  @user_model.destroy(current_user['id'])
  session.clear
  status 200
  { message: 'User account deleted successfully' }.to_json
end


# GET root route
get '/' do
  @users = @user_model.all.map { |user| user.reject { |k| k == 'password' } }
  erb :index
end
