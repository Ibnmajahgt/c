# Welcome to My Users App
***

## Task
Problem: error was found also after every session And challenge: did not get the what's the problem is at first

## Description
create
curl -X POST http://localhost:8080/users -d "firstname=John&lastname=D&age=30&password=yaya123&email=yaya@example.com"
sign in 
curl -X POST http://localhost:8080/sign_in -d "email=yaya@example.com&password=yaya123" --cookie-jar cookies.txt

sign out
curl -X DELETE http://localhost:8080/sign_out --cookie cookies.txt


Destroy User
curl -X DELETE http://localhost:8080/users --cookie cookies.txt


update
curl -X PUT http://localhost:8080/users -d "password=newpassword123" -H "Content-Type: application/x-www-form-urlencoded" --cookie cookies.txt

find user by id 
curl -X GET http://localhost:8080/users/1 --cookie cookies.txt

get all users
curl -X GET http://localhost:8080/users --cookie cookies.txt

## Installation
i've installed the full ruby install
i've installed bundle install which include about 5 gem inside it which makes my project to run 

## Usage
Wow it works very good and no any problem 

### The Core Team
i used terminal/Vs Code

<span><i>Made at <a href='https://qwasar.io'>Qwasar SV -- Software Engineering School</a></i></span>
<span><img alt='Qwasar SV -- Software Engineering School's Logo' src='https://storage.googleapis.com/qwasar-public/qwasar-logo_50x50.png' width='20px' /></span>
